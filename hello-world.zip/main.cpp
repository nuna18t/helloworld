/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream> //i/o library
using namespace std;// instead prefix std


int main() //header
{ //begin

	cout << "Hello world!" << endl;

	system("pause");

	return 0;//return to os

}//end